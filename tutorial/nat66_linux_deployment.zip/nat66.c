#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>

#include <net/ethernet.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/icmp6.h>
#include <netpacket/packet.h>

#include <linux/if.h>
#include <linux/if_tun.h>

#include <sys/ioctl.h>
#include <bits/endian.h>


#define BUFSIZE	8192

int version = 0;		/* Version of nat66 */



	#define CHECKSUM_CARRY(x) \
	    (x = (x >> 16) + (x & 0xffff), (~(x + (x >> 16)) & 0xffff))

/**
 * code to do a ones-compliment checksum
 */
static int
do_checksum_math(uint16_t *data, int len)
{
    int sum = 0;
    union {
        uint16_t s;
        uint8_t b[2];
    } pad;

    while (len > 1) {
        sum += *data++;
        len -= 2;
    }

    if (len == 1) {
        pad.b[0] = *(uint8_t *)data;
        pad.b[1] = 0;
        sum += pad.s;
    }

    return (sum);
}

/**
 * Checksum computation
 */
void
do_checksum(uint8_t *data) {
    struct ip6_hdr *ipv6;
    struct tcphdr *tcp;
    struct udphdr *udp;
    struct icmp6_hdr *icmp6;
    int sum,proto,len;

    sum = 0;
    ipv6 = NULL;


	ipv6 = (struct ip6_hdr *) ((unsigned char *) data + sizeof(struct tun_pi));
	len  = ntohs(ipv6->ip6_ctlun.ip6_un1.ip6_un1_plen);
	proto = ipv6->ip6_ctlun.ip6_un1.ip6_un1_nxt;

    switch (proto) {

        case IPPROTO_TCP:
            tcp = (struct tcphdr *)((unsigned char *)data + sizeof(struct ip6_hdr)+sizeof(struct tun_pi));
            tcp->check = 0;
            sum = do_checksum_math((uint16_t *)&ipv6->ip6_src, 32);
            sum += ntohs(IPPROTO_TCP + len);
            sum += do_checksum_math((uint16_t *)tcp, len);
            tcp->check = CHECKSUM_CARRY(sum);
            break;

        case IPPROTO_UDP:
            udp = (struct udphdr *)((unsigned char *)data + sizeof(struct ip6_hdr)+sizeof(struct tun_pi));
            udp->check = 0;
            sum = do_checksum_math((uint16_t *)&ipv6->ip6_src, 32);
            sum += ntohs(IPPROTO_UDP + len);
            sum += do_checksum_math((uint16_t *)udp, len);
            udp->check = CHECKSUM_CARRY(sum);
            break;

        case 58:
            icmp6 = (struct icmp6_hdr *)((unsigned char *)data + sizeof(struct ip6_hdr)+sizeof(struct tun_pi));
            icmp6->icmp6_cksum = 0;
            sum = do_checksum_math((u_int16_t *)&ipv6->ip6_src, 32);
            sum += ntohs(58 + len);
            sum += do_checksum_math((u_int16_t *)icmp6, len);
            icmp6->icmp6_cksum = CHECKSUM_CARRY(sum);
            break;


        default:
		printf("DEFAULT\n");
    }
}

 
/* Creation of the tunnel for changing the header */
int tun_create(char *dev)
{
	struct ifreq ifr;
	int fd, err;
	
	if( (fd = open("/dev/net/tun", O_RDWR)) < 0 )		return -1;

	memset(&ifr, 0, sizeof(ifr));
	
	/* Flags: IFF_TUN   - TUN device (no Ethernet headers) 
	   *		IFF_TAP   - TAP device	
	   *
	   *		IFF_NO_PI - Do not provide packet information  
	   */ 
	ifr.ifr_flags = IFF_TUN;	// | IFF_NO_PI; 
	if( *dev )
		strncpy(ifr.ifr_name , dev, IFNAMSIZ);
	
	if( (err = ioctl(fd, TUNSETIFF, (void *) &ifr)) < 0 )
	{
		close(fd);
		return err;
	}

	if( (err = ioctl(fd, TUNSETNOCSUM, (void *) &ifr)) < 0 )
	{
		close(fd);
		return err;
	}

	return fd;
}


/* Function for nating packets which come from the outside with a destination address begins with the cccc::/64 prefix */
void nat66_from_outside_to_sensor(int tun_outside_to_sensor)
{
	char buf6[BUFSIZE];
	int len,len_sent;
	struct ip6_hdr * ip6h;

        //printf("NAT FROM OUTSIDE TO SENSOR\n");
	/* Read what we have in the tunnel */
	len = read(tun_outside_to_sensor, buf6, BUFSIZE);
	ip6h = (struct ip6_hdr *) ((unsigned char *) buf6 + sizeof(struct tun_pi));

	int prefix_checksum = do_checksum_math((u_int16_t *)&ip6h->ip6_dst, 8);

	/* Packets that come with a dst addr that begin with cccc::/64 prefix must be nated to ::/64 */
	ip6h->ip6_dst.s6_addr[0]=0x00;
	ip6h->ip6_dst.s6_addr[1]=0x00;
	ip6h->ip6_dst.s6_addr[2]=0x00;
        ip6h->ip6_dst.s6_addr[3]=0x00;
        ip6h->ip6_dst.s6_addr[4]=0x00;
        ip6h->ip6_dst.s6_addr[5]=0x00;
        ip6h->ip6_dst.s6_addr[6]=0x00;
        ip6h->ip6_dst.s6_addr[7]=0x00;
	
//	/* Recalculate the checksum because dst addr has changed */
//       	do_checksum(buf6); 
	/* Recalculate the IID because the checksum must be the same */
/*        int old_iid;
        memcpy(&old_iid, &ip6h->ip6_dst.s6_addr[14], 2*sizeof(uint8_t));
        int nv_iid = old_iid - CHECKSUM_CARRY(prefix_checksum);
        memcpy(&ip6h->ip6_dst.s6_addr[14], &nv_iid, 2*sizeof(uint8_t));
*/
        int old_iid;
        memcpy(&old_iid, &ip6h->ip6_dst.s6_addr[12], 4*sizeof(uint8_t));
        int nv_iid = old_iid - CHECKSUM_CARRY(prefix_checksum);
        memcpy(&ip6h->ip6_dst.s6_addr[12], &nv_iid, 4*sizeof(uint8_t));

	/* Write in the tunnel to route it to the sensor network */
	len_sent = write(tun_outside_to_sensor, buf6, len);
}


/* Function for nating packet which comes from sensor network and that has a prefix ::/64 in source address */
void nat66_from_sensor_to_outside(int tun_sensor_to_outside,int tun_outside_to_sensor)
{
	char buf6[BUFSIZE];
	int len,len_sent;
	struct ip6_hdr * ip6h;

	/* Read what we have in the tunnel */
	len = read(tun_sensor_to_outside, buf6, BUFSIZE);
	ip6h = (struct ip6_hdr *) ((unsigned char *) buf6 + sizeof(struct tun_pi));
	/* Computation of the src addr - ::/64 prefix must be replaced by cccc::/64 prefix*/
	ip6h->ip6_src.s6_addr[0]=0xaa;
	ip6h->ip6_src.s6_addr[1]=0xaa;
        ip6h->ip6_src.s6_addr[2]=0x00;
        ip6h->ip6_src.s6_addr[3]=0x00;
        ip6h->ip6_src.s6_addr[4]=0x00;
        ip6h->ip6_src.s6_addr[5]=0x00;
        ip6h->ip6_src.s6_addr[6]=0x00;
        ip6h->ip6_src.s6_addr[7]=0x00;

	/* Recalculate the IID because the checksum must be the same - s6_addr[8] to s6_addr[15] */
	int prefix_checksum = do_checksum_math((u_int16_t *)&ip6h->ip6_src.s6_addr[0], 8);

	/* calcul 1 */
/*	int old_iid;
        memcpy(&old_iid, &ip6h->ip6_src.s6_addr[14], 2*sizeof(uint8_t));
	int nv_iid = old_iid + CHECKSUM_CARRY(prefix_checksum);
	if(nv_iid > 65535) {
		int old_iid_av;
		memcpy(&old_iid_av, &ip6h->ip6_src.s6_addr[12], 2*sizeof(uint8_t));
		nv_iid = nv_iid + old_iid_av;
		memcpy(&ip6h->ip6_src.s6_addr[12], &nv_iid, 4*sizeof(uint8_t)); 
	}
*/
	/* calcul 2 */
	int old_iid;
        memcpy(&old_iid, &ip6h->ip6_src.s6_addr[12], 4*sizeof(uint8_t));
        int nv_iid = old_iid + CHECKSUM_CARRY(prefix_checksum);
	memcpy(&ip6h->ip6_src.s6_addr[12], &nv_iid, 4*sizeof(uint8_t));  

	/* Write the changed packet in the tunnel to route it */
	len_sent = write(tun_outside_to_sensor, buf6, len);

}



int main(int argc, char *argv[])
{
	int tun_outside_to_sensor, tun_sensor_to_outside;
	int maxfd;
	fd_set fds;

	tun_outside_to_sensor = tun_create("tun_otos");
	tun_sensor_to_outside = tun_create("tun_sto");
	
	
	maxfd = 1 + ((tun_outside_to_sensor > tun_sensor_to_outside)?tun_outside_to_sensor:tun_sensor_to_outside);

	while(1)
	{
		FD_ZERO(&fds);
		FD_SET(tun_outside_to_sensor, &fds);
		FD_SET(tun_sensor_to_outside, &fds);
		select(maxfd, &fds, NULL, NULL, NULL);

		if( FD_ISSET(tun_outside_to_sensor, &fds) )
			nat66_from_outside_to_sensor(tun_outside_to_sensor);
		
		if( FD_ISSET(tun_sensor_to_outside, &fds) )
			nat66_from_sensor_to_outside(tun_sensor_to_outside,tun_outside_to_sensor);
	}
}

