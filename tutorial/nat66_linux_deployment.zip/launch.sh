#!/bin/bash
killall nat66
cc -o nat66 nat66.c 
./nat66 -v6 111:222:333::1 -d level0 &
echo 1 > /proc/sys/net/ipv4/ip_forward
echo 1 > /proc/sys/net/ipv6/conf/all/forwarding
ifconfig tun_otos up
ifconfig tun_sto up
# Remove any previous route
sudo ip -6 route flush table main 

# ROUTE CONFIGURATION FOR NATING FROM OUTSIDE TO SENSOR NETWORK
# Add a route for packets that goes to sensor network in order to nat them thanks to tunnel tun_otos - Only cccc::/64 packets must be natted
ip -6 route add aaaa::/64 dev tun_otos
# Add a route for packets that goes to sensor network once natted
ip -6 route add ::/64 dev tap0
# ROUTE CONFIGURATION FOR NATING SENSOR PACKET TO OUTSIDE 
# Add a rule for having source routing - Packet from a specific source will go to a specific table that will nat the packets or let them pass to the outside
# This rule says that every packet with ::/64 with a mark 4 must goes to table 4 in order to nat them
ip -6 rule add from ::/64 fwmark 4 table 4
# Add the rule to direct packet to the right table 
ip -6 route add default dev eth0	
ip -6 route add default dev tun_sto table 4

# Flush the previous ip6tables
sudo ip6tables -F -t mangle
# Mark the packet in order to make them go in the custom table
sudo ip6tables -t mangle -A PREROUTING -s ::/64  -j MARK --set-mark 4
