#!/bin/bash
#Run after launch.sh

ifconfig eth0 inet6 add bbbb::2/64
route -A inet6 add bbbb::1/128 dev eth0

